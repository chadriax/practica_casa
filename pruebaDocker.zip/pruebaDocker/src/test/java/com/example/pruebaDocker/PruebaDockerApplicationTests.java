package com.example.pruebaDocker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaDockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
